package fedulova.polina303.graphs;

import fedulova.polina303.graphs.model.NodeItem;

public interface OnPointClickListener {
    void onClick(NodeItem node);
}
