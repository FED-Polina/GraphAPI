package fedulova.polina303.graphs.model;

import com.google.gson.annotations.SerializedName;

public class TokenDTO {
    @SerializedName("token")
    public String token;
}
