package fedulova.polina303.graphs;

import java.util.List;

import fedulova.polina303.graphs.model.LinkItem;
import fedulova.polina303.graphs.model.NodeItem;

public interface OnPointXYChangedListener {

    void onXYChanged(NodeItem newNode, List<LinkItem> newLinks);
}