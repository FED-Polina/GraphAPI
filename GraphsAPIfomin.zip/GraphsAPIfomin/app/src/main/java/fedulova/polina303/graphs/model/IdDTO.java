package fedulova.polina303.graphs.model;

import com.google.gson.annotations.SerializedName;

public class IdDTO {
    @SerializedName("id")
    public Integer graphId;
}
